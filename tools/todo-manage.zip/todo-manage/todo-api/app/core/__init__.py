# Core module for configuration and database
