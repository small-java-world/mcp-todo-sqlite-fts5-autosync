#!/usr/bin/env python3
"""
devctl.py — worktree-aware docker compose runner (with env autogen support)

- Computes unique COMPOSE_PROJECT_NAME and port offsets per worktree
- Generates .env.worktree/<project>.env
- Optional: --db-port auto   (compute DB_HOST_PORT and enable override compose)
          : --db-port none   (clear DB_HOST_PORT)
"""
import os, sys, subprocess, hashlib, re, pathlib, argparse

ROOT = pathlib.Path(__file__).resolve().parents[1]

def sh(cmd, cwd=ROOT, check=True):
    p = subprocess.run(cmd, cwd=cwd, shell=True, capture_output=True, text=True)
    if check and p.returncode != 0:
        print(p.stdout)
        print(p.stderr, file=sys.stderr)
        raise SystemExit(p.returncode)
    return p.stdout.strip()

def sanitize(s: str) -> str:
    return re.sub(r'[^a-z0-9]+','-', s.lower()).strip('-')[:24]

def detect_worktree_slug():
    try:
        branch = sh("git rev-parse --abbrev-ref HEAD") or "detached"
    except Exception:
        branch = "unknown"
    try:
        gitdir = sh("git rev-parse --git-dir")
    except Exception:
        gitdir = ".git"
    h = hashlib.sha1(os.path.abspath(gitdir).encode()).hexdigest()[:6]
    proj = f"aa-{sanitize(branch)}-{h}"
    # derive stable port offsets from hash
    off = int(h, 16) % 500
    web_port = 3000 + off
    api_port = 8000 + off
    # db port suggestion (host) if needed -> different range to avoid 5432 collisions
    db_port = 5400 + off
    db_name = f"app_{h}"
    return {
        "PROJECT": proj,
        "HASH6": h,
        "WEB_HOST_PORT": str(web_port),
        "API_HOST_PORT": str(api_port),
        "DB_NAME": db_name,
        "DB_USER": "app",
        "DB_PASSWORD": "app",
        "NEXT_PUBLIC_API_BASE": f"http://localhost:{api_port}",
        "API_CORS_ORIGINS": f"http://localhost:{web_port},http://web:3000",
        "DB_HOST_PORT_SUGGEST": str(db_port),
    }

def ensure_env_file(values: dict, db_port_mode: str = "none") -> pathlib.Path:
    envdir = ROOT / ".env.worktree"
    envdir.mkdir(exist_ok=True)
    envpath = envdir / f"{values['PROJECT']}.env"
    lines = []
    for k in ["WEB_HOST_PORT","API_HOST_PORT","DB_NAME","DB_USER","DB_PASSWORD","NEXT_PUBLIC_API_BASE","API_CORS_ORIGINS"]:
        lines.append(f"{k}={values[k]}")
    # DB host port publication
    if db_port_mode == "auto":
        lines.append(f"DB_HOST_PORT={values['DB_HOST_PORT_SUGGEST']}")
    else:
        lines.append(f"# DB_HOST_PORT={values['DB_HOST_PORT_SUGGEST']}  # uncomment to publish")
    envpath.write_text("\n".join(lines) + "\n", encoding="utf-8")
    return envpath

def compose_cmd(files: list, envfile: pathlib.Path, project: str) -> str:
    parts = ["docker","compose","-p",project,"--env-file",str(envfile)]
    for f in files:
        parts += ["-f", str(ROOT / "docker" / f)]
    return " ".join(parts)

def get_envfile_and_project(db_port_mode="none"):
    vals = detect_worktree_slug()
    envfile = ensure_env_file(vals, db_port_mode=db_port_mode)
    return envfile, vals["PROJECT"]

def main():
    ap = argparse.ArgumentParser()
    sub = ap.add_subparsers(dest="cmd")

    env_p = sub.add_parser("env")
    env_p.add_argument("--db-port", choices=["auto","none"], default="none")

    up_p = sub.add_parser("up")
    up_p.add_argument("--e2e", action="store_true")
    up_p.add_argument("--db-port", choices=["auto","none"], default="none")

    down_p = sub.add_parser("down")
    down_p.add_argument("--e2e", action="store_true")

    test_p = sub.add_parser("test")
    test_p.add_argument("target", choices=["js","py","ui","api","all"])

    mig_p = sub.add_parser("migrate")
    mig_p.add_argument("action", choices=["upgrade","downgrade"])
    mig_p.add_argument("rev", nargs="?", default="head")

    args = ap.parse_args()

    if args.cmd == "env":
        envfile, project = get_envfile_and_project(db_port_mode=getattr(args,"db_port","none"))
        print(f"PROJECT={project}")
        print(envfile.read_text())
        return

    # choose files
    files = ["docker-compose.dev.yml"]
    if getattr(args, "e2e", False):
        files = ["docker-compose.e2e.yml"]

    # include db-port override if env has DB_HOST_PORT or if requested
    envfile, project = get_envfile_and_project(db_port_mode=getattr(args,"db_port","none"))
    env_text = pathlib.Path(envfile).read_text()
    if "DB_HOST_PORT=" in env_text and not env_text.strip().startswith("# DB_HOST_PORT"):
        # include override
        files.append("docker-compose.dbport.override.yml")

    base = compose_cmd(files, envfile, project)

    def sh(cmd, check=True):
        import subprocess, sys
        p = subprocess.run(cmd, cwd=str(ROOT), shell=True, capture_output=True, text=True)
        if check and p.returncode != 0:
            print(p.stdout)
            print(p.stderr, file=sys.stderr)
            raise SystemExit(p.returncode)
        return p.stdout.strip()

    if args.cmd == "up":
        sh(f"{base} up -d --build")
    elif args.cmd == "down":
        sh(f"{base} down -v")
    elif args.cmd == "test":
        if args.target in ("js","all"):
            sh(f"{base} exec web pnpm test:unit", check=False)
        if args.target in ("py","all"):
            sh(f"{base} exec api pytest -q", check=False)
        if args.target in ("ui","all"):
            sh(f"{base} up --build --abort-on-container-exit e2e-playwright", check=False)
        if args.target in ("api","all"):
            sh(f"pytest -q apps/api/tests_e2e", check=False)
    elif args.cmd == "migrate":
        sh(f"{base} exec api alembic {args.action} {args.rev}")
    else:
        ap.print_help()

if __name__ == "__main__":
    main()
