# Worktree-aware Docker Scaffold
Next.js + FastAPI + Postgres + Playwright E2E + Alembic
（**git worktree 対応 / 自動 .env 生成 / 並列ブランチの完全分離**）

---

## 0. このスキャフォールドのねらい
- **git worktree** で複数ブランチを同時に開発しても、**ポート / コンテナ / ネットワーク / ボリューム / DB名**が**衝突しない**。
- worktree を作った瞬間に **`.env` を自動生成**（Git hooks） → **手作業ゼロ**で起動できる。
- アプリは **Next.js（web）** + **FastAPI（api）**、DB は **Postgres**、マイグレーションは **Alembic**。
- E2E は **Playwright（UI）** と **httpx（API）** で**実サーバ**に対して検証。

> 本テンプレートは **ローカル開発向け**です。プロダクション運用には後述の「セキュリティ注意」「拡張案」を踏まえて調整してください。

---

## 1. クイックスタート（最短 10 秒）

### 前提
- Docker Engine / Docker Compose v2 が導入済み
- Python 3.10+（devctl 実行用）
- Node.js 18+（Next.js 開発時のみローカルで必要）

### 初回だけ（hooks の導入）
```bash
bash tool-scripts/install-hooks.sh
```

### 新しい worktree を作って起動
```bash
git worktree add ../wt-feature feature/my-branch
cd ../wt-feature

# ← 初回 checkout 完了時点で自動的に .env が生成される

python tool-scripts/devctl.py up
# Web: http://localhost:<WEB_HOST_PORT>
# API: http://localhost:<API_HOST_PORT>
```

### UT / E2E / マイグレーション
```bash
python tool-scripts/devctl.py test js      # Next/Vitest（web コンテナ内）
python tool-scripts/devctl.py test py      # FastAPI/pytest（api コンテナ内）
python tool-scripts/devctl.py e2e ui       # Playwright（コンテナ経由で /login フロー検証）
python tool-scripts/devctl.py e2e api      # httpx E2E（実サーバに対して 2FA ハンドシェイク検証）
python tool-scripts/devctl.py migrate upgrade   # Alembic -> head
python tool-scripts/devctl.py down         # 終了＆ボリューム含む破棄
```

---

## 2. なぜ「worktree-aware」が必要？
ひとつのリポジトリで複数のブランチを**同時に**検証する場合、ローカルのポート（3000/8000）や DB、コンテナ名、ボリューム名が**取り合い**になります。  
本スキャフォールドは次の仕組みで**自動衝突回避**を行います：

- **COMPOSE_PROJECT_NAME** = `aa-<branch>-<hash6>`  
  → Docker Compose が作る **ネットワーク/ボリューム/コンテナ**名が worktree ごとに固有化
- **ポート**：`WEB_HOST_PORT=3000+Δ` / `API_HOST_PORT=8000+Δ`（Δ は `<hash6>` 由来の安定オフセット）
- **DB 名**：`DB_NAME=app_<hash6>`（同じ Postgres サーバでも DB 名で分離）

> `devctl.py env-gen` が `.env.worktree/<project>.env` と `.env` を生成し、値を注入します。

---

## 3. 全体構成（アーキテクチャ）
```
                 ┌───────────────────────────────────────────┐
                 │ git worktree                              │
                 └─────┬─────────────────────────────────────┘
                       │  post-checkout hook（初回のみ）
                       ▼
                devctl.py env-gen
                       │  生成
     .env.worktree/aa-<branch>-<hash6>.env   ＋   .env（任意）
                       │  参照
                       ▼
          docker compose -p aa-<branch>-<hash6>                  -f docker-compose.dev.yml                         [-f docker-compose.db-expose.yml]  ← DB公開時だけ
                       │
           ┌───────────┴───────────┐
           │           │           │
         web         api          db
      (Next.js)   (FastAPI)   (Postgres)
           │           │
           └───── Playwright / httpx（E2E）
```

---

## 4. ディレクトリ構成（抜粋）
```
.
├─ .githooks/                     # リポジトリ管理の Git hooks
│  ├─ post-checkout               # 初回 checkout で .env 自動生成
│  └─ post-merge                  # 予防的に .env 未作成なら生成
├─ .env.worktree/                 # worktree ごとの .env 保存先（Git 管理外推奨）
├─ docker/
│  ├─ docker-compose.dev.yml      # 開発用（web/api/db + optional e2e コンテナ）
│  ├─ docker-compose.e2e.yml      # E2E 専用
│  └─ docker-compose.db-expose.yml# DB ポート公開 overlay（必要時のみ適用）
├─ tool-scripts/
│  ├─ devctl.py                   # env-gen / up / down / test / migrate / e2e
│  └─ install-hooks.sh            # hooks を core.hooksPath に設定
├─ apps/
│  ├─ web/                        # Next.js（/login UI 付き）
│  ├─ api/                        # FastAPI（2FA ハンドシェイク + Alembic）
│  └─ web-e2e/                    # Playwright（UI E2E）
└─ apps/api/tests_e2e/            # httpx E2E
```

---

## 5. 環境変数と .env ファイル

### 生成されるファイル
- `.env.worktree/aa-<branch>-<hash6>.env`（必ず生成 / devctl が参照）
- `.env`（`--write-root` 指定時のみ。IDE から見やすくするための**複製**）

### 主なキー（自動算出）
| key | 例 | 説明 |
|---|---|---|
| `WEB_HOST_PORT` | `3148` | Web を `http://localhost:3148` で公開 |
| `API_HOST_PORT` | `8148` | API を `http://localhost:8148` で公開 |
| `DB_NAME` | `app_a1b2c3` | Postgres の DB 名（worktree 固有） |
| `NEXT_PUBLIC_API_BASE` | `http://localhost:8148` | Next.js から API へ向ける Base URL |
| `API_CORS_ORIGINS` | `http://localhost:3148,http://web:3000` | CORS 許可（ローカル / Compose 内） |
| `DB_USER`/`DB_PASSWORD` | `app` / `app` | サンプル用資格情報 |

### DB ポートをローカル公開したいとき
```bash
python tool-scripts/devctl.py env-gen --write-root --db-expose auto
# → .env に DB_HOST_PORT=55xxx が追記される
python tool-scripts/devctl.py up
# → docker/docker-compose.db-expose.yml が自動適用され、
#    ホストの 55xxx → db:5432 が開放される
```
接続例：
```bash
psql "postgresql://app:app@localhost:$DB_HOST_PORT/$DB_NAME"
```

---

## 6. devctl コマンド一覧
```txt
python tool-scripts/devctl.py env-gen [--write-root] [--db-expose off|auto]
python tool-scripts/devctl.py env
python tool-scripts/devctl.py up [--e2e]
python tool-scripts/devctl.py down [--e2e]
python tool-scripts/devctl.py test (js|py|ui|api|all)
python tool-scripts/devctl.py migrate (upgrade|downgrade) [rev=head]
```
- **env-gen**: worktree 固有の `.env.worktree/<project>.env` を生成。`--write-root` で `.env` も出力。  
  `--db-expose auto` 指定時のみ DB を host に公開（55xxx）。
- **env**: 現在の project と `.env` の中身を表示。
- **up / down**: 開発スタック起動/停止（`--e2e` で E2E 用 Compose を使用）。
- **test**: `js`（Vitest/Next）/ `py`（pytest/FastAPI）/ `ui`（Playwright）/ `api`（httpx）/ `all`。
- **migrate**: Alembic を実行（`upgrade head` / `downgrade base` 等）。

---

## 7. Git hooks（自動 .env 生成）
- `.githooks/post-checkout` が **初回 checkout** を検知し、`.env` が無ければ `env-gen --write-root` を実行します。
- `.githooks/post-merge` は保険（`.env` が消えている場合に再生成）。
- 有効化：
  ```bash
  bash tool-scripts/install-hooks.sh
  # → git config core.hooksPath .githooks
  ```

> 常に DB を公開したい場合は、`post-checkout` のコマンドを  
> `env-gen --write-root --db-expose auto` に変更してください。

---

## 8. Docker Compose スタック
- **docker-compose.dev.yml** … ローカル開発（web/api/db + e2e Playwright コンテナ）  
- **docker-compose.e2e.yml** … E2E 専用（CI などでまとめて実行）  
- **docker-compose.db-expose.yml** … DB ポート公開の **オーバーレイ**（`DB_HOST_PORT` が存在するときだけ devctl が読み込み）

> Compose の `-p <project>` により、**ネットワーク/ボリューム**は `<project>_default` / `<project>_pgdata` のように worktree ごとに分離されます。

---

## 9. データベースとマイグレーション（Alembic）
- FastAPI は `DATABASE_URL`（例：`postgresql+psycopg://app:app@db:5432/app_<hash6>`）を使用します。
- 代表コマンド：
  ```bash
  python tool-scripts/devctl.py migrate upgrade     # 最新へ
  python tool-scripts/devctl.py migrate downgrade base
  ```
- **DB をやり直したい**：`devctl.py down` でボリュームも破棄（worktree ごと）。

---

## 10. E2E の流れ
- **UI（Playwright）**：`apps/web-e2e/tests/ac-fa-001.login.flow.spec.ts`  
  - `/login` ページで **202 → OTP → 200 + Cookie** の 2FA ハンドシェイクを検証。
- **API（httpx）**：`apps/api/tests_e2e/test_login_flow_httpx.py`  
  - 実サーバ（`http://localhost:<API_HOST_PORT>`）に対して 2FA ハンドシェイクを確認。

---

## 11. TDD・既存拡張フローとの接続（任意）
- 既存の「**設計書駆動（Spec/Card/Delta）＋ AC-ID 限定テスト**」運用に接続できます。  
  - Web: `pnpm test:unit -- -t "<AC-ID>"`  
  - API: `pytest -k "<AC-ID>"`  
- PR テンプレ自動生成、SoT チェックなどは前回のスキャフォールドと組み合わせて導入できます。

---

## 12. CI/CD 取り込み例（抜粋）
- **branch/worktree ごとに並列**起動したい場合、CI で `env-gen` を実行してから Compose を起動：
```yaml
- name: Generate worktree env
  run: python tool-scripts/devctl.py env-gen --write-root
- name: Compose up
  run: python tool-scripts/devctl.py up --e2e
- name: Tests
  run: |
    python tool-scripts/devctl.py test js
    python tool-scripts/devctl.py test py
    python tool-scripts/devctl.py e2e ui
    python tool-scripts/devctl.py e2e api
- name: Compose down
  if: always()
  run: python tool-scripts/devctl.py down --e2e
```

---

## 13. トラブルシュート
- **ポートが開かない**：`python tool-scripts/devctl.py env` でポートを確認。既存プロセスが掴んでいないか確認。
- **DB に接続できない**：`DB_HOST_PORT` を付け忘れていないか。`db-expose` overlay が当たっているか。
- **Windows / WSL2**：Docker Desktop + WSL2 環境での**ファイル監視**は負荷が高い場合あり。Next の `pnpm dev` をホスト側で起動する運用も検討。
- **Playwright の依存**：コンテナ内で `pnpm exec playwright install --with-deps` を実行（Compose に同梱済み）。

---

## 14. セキュリティ上の注意（開発専用の実装）
- Cookie、CORS、OTP（固定値）、tx の扱いは**開発用の簡易実装**です。本番では必ず以下を強化：  
  - セッション管理（署名/暗号化/失効/SameSite/Secure）  
  - レート制限 / ロックアウト / ログ監査 / 監査証跡  
  - Secrets / 環境変数の管理（CI/CD Secrets, .env は Git 管理禁止）

---

## 15. よくある質問（FAQ）
**Q. DB を公開したくない worktree と公開したい worktree を混在できますか？**  
A. はい。`env-gen --db-expose auto` を**実行した worktree だけ**公開されます。

**Q. 既に生成済みの .env を上書きしたい**  
A. `env-gen --write-root` を再実行してください（必要に応じて手動編集）。

**Q. プロジェクト名のアルゴリズムを変えたい**  
A. `devctl.py` の `detect_worktree_slug()` を編集（例：PR 番号や CI のラン ID を混ぜる）。

---

## 16. 次の一手（拡張案）
- **Compose profiles**（dev/e2e/prod）でサービス構成を段階的に切替
- **Nginx 逆プロキシ** / HTTPS 終端 / ローカル証明書（mkcert）
- **データ初期化シード**（`db` 起動時にサンプルユーザ投入）
- **PRプレビュー環境**を GitHub Actions + worktree 方式で自動生成

---

Happy hacking! 🚀
